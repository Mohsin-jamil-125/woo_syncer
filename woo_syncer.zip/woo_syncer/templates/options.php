<?php
require_once PRODUCT_SYNC_PLUGIN_PATH . 'includes/classes/Syncer_Store.php';

use Ufit\product_syncer\Syncer_Store as Syncer_Store;
use Ufit\product_syncer\Syncer_User as Syncer_User;

?>
<h1>Settings</h1>
<form action="options.php" method="post">
    <?php
    $nonce = wp_create_nonce("delete_syncer_user");
    settings_fields('product_syncer');
    do_settings_sections('syncer_setting_page');
    $Syncer_User = new Syncer_User();
    $Syncer_Store = new Syncer_Store();
    ?>
    <table class="form-table" role="presentation">
        <tbody>
        <?php
        if (!$Syncer_User->has()) {
            ?>
            <tr>
                <th scope="row">Store name</th>
                <td>
                    <input type="text" name="product_syncer[store_name]" id="ps_store_name" value="">
                </td>
            </tr>
            <tr>
                <th scope="row">Store type</th>
                <td>
                    <input type="radio" name="product_syncer[store_is]" id="user_is_source"
                           value="source" <?php checked('source', $Syncer_User->type, true); ?>>
                    <label for="user_is_source">Source Store</label>
                    <input type="radio" name="product_syncer[store_is]" id="user_is_destination"
                           value="destination" <?php checked('destination', $Syncer_User->type, true); ?>>
                    <label for="user_is_destination">Destination Store</label>
                </td>
            </tr>
            <?php
        } else {
            ?>
            <tr>
                <th scope="row">You are activate</th>
                <td>

                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    <?php
    if ($Syncer_User->has()) {
        ?>
<!--        <input name="delete" class="button button-primary ufit-delete-syncer-user" type="button"-->
<!--               value="--><?php //esc_attr_e('Delete'); ?><!--" data-nonce="--><?//= $nonce ?><!--"/>-->
        <?php
    } else {
        ?>
        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e('Save'); ?>"/>
        <?php
    }
    ?>
</form>
