<?php
include_once PRODUCT_SYNC_TEMPLATE_PATH . 'layouts/header.php';
?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Product Management</h2>
        </div>
        <div class="pull-right">
            <!--            <a class="btn btn-success" href="#"> Add New Store</a>-->
        </div>
    </div>
</div>


<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>is Synck</th>
        <th width="280px">Action</th>
    </tr>
    <?php
    $i = 0;
    foreach ($product_data->data as $product) {
        ?>
        <tr>
            <td><?= ++$i ?></td>
            <td><?= $product->title ?></td>
            <td>No</td>
            <td>
                <a class="btn btn-info" href="">Synck</a>
            </td>
        </tr>

        <?php
    }
    ?>
</table>


<?php
include_once PRODUCT_SYNC_TEMPLATE_PATH . 'layouts/footer.php';
?>
