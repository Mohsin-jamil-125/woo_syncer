<?php
include_once PRODUCT_SYNC_TEMPLATE_PATH . 'layouts/header.php';
?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Store Management</h2>
        </div>
    </div>
</div>

<table class="table table-bordered">
    <thead>
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>Key</th>
        <th width="280px">Show</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $i = 0;
    $nonce = wp_create_nonce("get_source_products_nonce");
    foreach ($stores as $store) {
        $params = array(
            'page'  => 'product-syncer-products',
            'store' => $stor->id
        );

        $url = add_query_arg($params, admin_url('admin.php'));
        ?>
        <tr>
            <td><?= ++$i ?></td>
            <td><?= $store->name ?></td>
            <td><?= $store->key ?></td>
            <td>
                <button class="btn btn-info ufit-show-store-products" data-nonce="<?= $nonce ?>" data-store-id="<?= $store->id ?>">Products</button>
            </td>
        </tr>
        <?php
    }
    ?>
    </tbody>
</table>

<div class="modal fade" id="ufit-source-products-model" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Prodcts</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body ufit-model-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Name</th>
                        <th scope="col">SKU</th>
                        <th scope="col">image</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>


<?php
include_once PRODUCT_SYNC_TEMPLATE_PATH . 'layouts/footer.php';
?>
