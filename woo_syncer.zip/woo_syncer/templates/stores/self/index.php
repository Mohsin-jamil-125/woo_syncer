<?php
include_once PRODUCT_SYNC_TEMPLATE_PATH . 'layouts/header.php';
?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Your Store</h2>
        </div>
    </div>
</div>

<form class="form-horizontal">
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Name</label>
        <div class="col-sm-10">
            <input type="email" class="form-control" id="" value="<?= $this->name ?>" disabled>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Unique Key</label>
        <div class="col-sm-10">
            <input type="email" class="form-control" id="" value="<?= $this->key ?>" disabled>
        </div>
    </div>
</form>

<?php
include_once PRODUCT_SYNC_TEMPLATE_PATH . 'layouts/footer.php';
?>
