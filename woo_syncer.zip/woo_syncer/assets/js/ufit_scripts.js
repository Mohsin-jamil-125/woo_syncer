jQuery(document).ready(function () {
    const $ = jQuery;

    ufit.activeStore = {
        "ID": -1,
        "products": []
    };

    $(document).on("click", ".ufit-toggle-product-sync", function () {
        let $this = $(this);
        let syncer_product_id = $this.data("productId");
        nonce = $this.data("nonce");

        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "toggle_product_sync", syncer_product_id: syncer_product_id, nonce: nonce},
            success: function (response) {
                if (response.success) {
                    $is_sync = response.data.sync ? "Yes" : "No";
                    $this.html($is_sync)
                } else {
                    alert(response.message);
                }
            }
        })
    });

    $(document).on("click", ".ufit-delete-syncer-user", function () {
        let $this = $(this);
        let nonce = $this.data("nonce");

        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "delete_syncer_user", nonce: nonce},
            success: function (response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            }
        })
    });

    $(document).on("click", ".ufit-show-store-products", function () {
        let $this = $(this);
        ufit.activeStore.ID = $this.data("storeId");
        let nonce = $this.data("nonce");

        let data = {action: "get_source_products", nonce: nonce, "storeId": ufit.activeStore.ID};
        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: data,
            success: function (response) {
                if (response.success) {
                    let data = response.data;

                    ufit.activeStore.products = data.data;
                    let HTML = "";
                    ufit.activeStore.products.forEach(function (product, index) {
                        HTML += '<tr>';
                        HTML += `<td scope="col">${index + 1}</td>`;
                        HTML += `<td scope="col">${product.title}</td>`;
                        HTML += `<td scope="col">${product.sku}</td>`;
                        HTML += `<td scope="col" style="width: 92px"><img src="${product.images_url}" alt="${product.title}" class="img-thumbnail"></td>`;
                        HTML += `<td scope="col">
                                    <button class="btn btn-info ufit-add-product" data-nonce="${ufit.addProductNonce}" data-product-id="${product.id}" data-index="${index}">Add</button>
                                  </td>`;
                        HTML += '</tr>';
                    });
                    $("#ufit-source-products-model").find("tbody").html(HTML);
                    $("#ufit-source-products-model").modal("show");
                } else {
                    alert(response.message);
                }
            }
        })
    });

    $(document).on("click", ".ufit-add-product", function () {
        let productIds = $(this).data("productId");
        ufit_import_products(productIds);
    });
});


let ufit_import_products = (productIds) => {
    let data = {
        "action": "import_source_products",
        "storeID": ufit.activeStore.ID,
        "productIds": productIds,
        "nonce": ufit.addProductNonce,
    };

    jQuery.ajax({
        type: "post",
        dataType: "json",
        url: ufit.ajaxurl,
        data: data,
        success: function (response) {
            if (response.success) {
                let data = response.data;
                alert(response.message);
            } else {
                alert(response.message);
            }
        }
    });
};
