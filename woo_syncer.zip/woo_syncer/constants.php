<?php
if(!defined('PRODUCT_SYNC_REST_API_URL')) define('PRODUCT_SYNC_REST_API_URL', 'e-comm-sync/v1/');
if(!defined('PRODUCT_SYNC_API_URL')) define('PRODUCT_SYNC_API_URL', 'http://product_syncer.local/api/');

if(!defined('PRODUCT_SYNC_PLUGIN_PATH')) define('PRODUCT_SYNC_PLUGIN_PATH', plugin_dir_path( __FILE__ ));

if(!defined('PRODUCT_SYNC_TEMPLATE_PATH')) define('PRODUCT_SYNC_TEMPLATE_PATH', PRODUCT_SYNC_PLUGIN_PATH.'templates/');

if(!defined('PRODUCT_SYNC_PLUGIN_DIR')) define('PRODUCT_SYNC_PLUGIN_DIR', '/woo_syncer/');
if(!defined('PRODUCT_SYNC_JS_DIR')) define('PRODUCT_SYNC_JS_DIR', PRODUCT_SYNC_PLUGIN_DIR.'assets/js/');
if(!defined('PRODUCT_SYNC_CSS_DIR')) define('PRODUCT_SYNC_CSS_DIR', PRODUCT_SYNC_PLUGIN_DIR.'assets/css/');

global $wpps;
$WPPS = array(
    'table_prefix' => 'ps_',
    'version'      => 1.0,
    'has_store'    => false
);

