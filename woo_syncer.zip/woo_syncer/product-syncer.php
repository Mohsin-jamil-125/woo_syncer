<?php
/**
 * Plugin Name: Product Syncer
 * Plugin URI:
 * Description: ABC.
 * Version: 1.0.0
 * Author: Uforia Infotech
 * Author URI:
 **/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once 'constants.php';
require_once 'includes/classes/Curl.php';
require_once 'includes/classes/Basic.php';

require_once 'includes/classes/rest_api/Rest_API.php';
require_once 'includes/classes/Syncer_Store.php';
require_once 'includes/classes/Sync_DB.php';
require_once 'includes/classes/sync_api/Product.php';
require_once 'includes/classes/Syncer_User.php';

require_once 'includes/classes/woo/Product.php';


require_once 'includes/classes/Ajax_Controller.php';

use Ufit\product_syncer\Basic as Basic;
use Ufit\product_syncer\Sync_DB as Syncer_DB;
use Ufit\product_syncer\sync_api\Product as Syncer_Product;
use Ufit\product_syncer\Syncer_Store as Syncer_Store;
use Ufit\product_syncer\Syncer_User as Syncer_User;
use Ufit\product_syncer\woo\Product as Woo_Product;

class Product_Syncer extends Basic
{
    public $version = 1.0;
    public $cacheVersion = '1.0.1';
    public $tDomain = 'productSuncer';

    function __construct()
    {
        register_activation_hook(__file__, array($this, 'on_plugin_activation'));

        add_action('admin_init', array($this, 'admin_init'));
        add_action('init', array($this, 'action_init'));
        add_action('admin_menu', array($this, 'admin_menu'));
    }

    public function on_plugin_activation()
    {
        $Syncer_DB = new Sync_DB();
        $Syncer_DB->create_tables();
    }

    public function admin_init()
    {
        $this->register_settings();

        $this->admin_actions();

        global $WPPS;
        $Syncer_Store = new Syncer_Store();
        $WPPS['has_store'] = $Syncer_Store->has();
        if ($WPPS['has_store']) {
            $this->bind_sync_hooks();
        }
    }

    public function admin_actions()
    {
        $Syncer_Store = new Syncer_Store();
        add_action('admin_action_ufit_add_source_store', array($Syncer_Store, 'add_source'));
    }

    public function bind_sync_hooks()
    {
        $Woo_Product = new _Product();
        add_action("save_post_product", array($Woo_Product, "action_on_save_product"));
        add_action("added_post_meta", array($Woo_Product, "action_on_save_product"));
        add_action("updated_post_meta", array($Woo_Product, "action_on_save_product"));
        add_action("woocommerce_update_product", array($Woo_Product, "action_on_save_product"));
    }

    public function action_init()
    {
        $this->script_enqueuer();
        $this->style_enqueuer();

    }

    private function script_enqueuer()
    {
        wp_register_script("ufit_script", WP_PLUGIN_URL . PRODUCT_SYNC_JS_DIR . 'ufit_scripts.js', array('jquery'), $this->cacheVersion);

        $localizeVariable = array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'addProductNonce' => wp_create_nonce("add_source_products_nonce"),
        );
        wp_localize_script('ufit_script', 'ufit', $localizeVariable);

        wp_enqueue_script('jquery');
        wp_enqueue_script('ufit_script');

        wp_register_script('ufit_bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js');
        wp_enqueue_script('ufit_bootstrap');
    }

    private function style_enqueuer()
    {
        wp_register_style("ufit_style", WP_PLUGIN_URL . PRODUCT_SYNC_CSS_DIR . 'ufit_style.css');
        wp_enqueue_style('ufit_style');

        wp_register_style('ufit_bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css');
        wp_enqueue_style('ufit_bootstrap');
    }

    /**
     * Register a menu page.
     */
    public function admin_menu()
    {
        $Syncer_Store = new Syncer_Store();
        $Syncer_User = new Syncer_User();
        $Syncer_Product = new Syncer_Product();

        $capability = 'manage_options';
        add_menu_page(
            __('Product Syncer', $this->tDomain),
            __('Product Syncer', $this->tDomain),
            $capability,
            'product-syncer',
            array($this, 'render_option_page'),
            '',
            6
        );

        if ($Syncer_Store->has()) {
            switch ($Syncer_Store->type) {
                case 'source':
                    add_submenu_page(
                        'product-syncer',
                        __('Store', $this->tDomain),
                        __('Store', $this->tDomain),
                        $capability,
                        'product-syncer-store',
                        array($Syncer_Store, 'self_list')
                    );

                    add_submenu_page(
                        'product-syncer',
                        __('Products', $this->tDomain),
                        __('Products', $this->tDomain),
                        $capability,
                        'product-syncer-products',
                        array($Syncer_Product, 'self_list')
                    );
                    break;
                case 'destination':
                    add_submenu_page(
                        'product-syncer',
                        __('Stores', $this->tDomain),
                        __('Stores', $this->tDomain),
                        $capability,
                        'product-syncer-stores',
                        array($Syncer_Store, 'import_list')
                    );
                    add_submenu_page(
                        'product-syncer',
                        __('Add Store', $this->tDomain),
                        __('Add Store', $this->tDomain),
                        $capability,
                        'product-syncer-add-store',
                        array($Syncer_Store, 'create')
                    );
                    add_submenu_page(
                        'product-syncer',
                        __('Sync Products', $this->tDomain),
                        __('Sync Products', $this->tDomain),
                        $capability,
                        'product-syncer-products',
                        array($Syncer_Product, 'list_sync_products')
                    );
                    break;
            }
        }
    }

    public function render_option_page()
    {
        include_once PRODUCT_SYNC_TEMPLATE_PATH . 'options.php';
    }

    public function register_settings()
    {
        register_setting('product_syncer', 'product_syncer', array($this, 'product_syncer_options_validate'));
        add_settings_section('syncer_settings_section', 'Product Syncer Settings', array($this, 'dbi_plugin_section_text'), 'syncer_setting_page');
    }


    function dbi_plugin_section_text()
    {
        echo '';
    }

    public function product_syncer_options_validate($input)
    {
        $syncer_type = $input['store_is'];
        $store_name = $input['store_name'];
        $properties = array(
            'type' => $syncer_type
        );

        $Syncer_User = new Syncer_User($properties);
        if ($Syncer_User->has()) {

        } else {
            $response = $Syncer_User->add();

            $properties = array(
                'type' => $syncer_type,
                'name' => $store_name
            );

            $Syncer_Store = new Syncer_Store($properties);
            $Syncer_Store->add();
        }
        return $input;
    }

    public function add_vedor()
    {

    }
}

new Product_Syncer();
