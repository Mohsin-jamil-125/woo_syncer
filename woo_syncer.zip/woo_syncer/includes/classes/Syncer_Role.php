<?php
namespace Ufit\product_syncer;

defined( 'ABSPATH' ) || exit;

require_once 'Curl.php';

use Ufit\product_syncer\Curl as Curl;

class Syncer_Role{

    public function get(){
        $Curl = new Curl(PRODUCT_SYNC_API_URL.'roles');
        return $Curl->Cget();
    }
}
