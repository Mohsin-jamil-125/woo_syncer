<?php

namespace Ufit\product_syncer\woo;

defined('ABSPATH') || exit;


class Product
{
    public $syncer_fields = array('store_product_id', 'type', 'sku', 'name', 'published', 'is_featured', 'catalog_visibility', 'short_description', 'description', 'date_sale_price_starts', 'date_sale_price_ends', 'tax_status', 'tax_class', 'in_stock', 'stock', 'backorders', 'sold_individually', 'weight', 'length', 'width', 'height', 'reviews_allowed', 'purchase_note', 'sale_price', 'regular_price', 'categories', 'tags', 'shipping_class', 'images', 'download_limit', 'download_expiry', 'parent_id', 'grouped_products', 'external_url', 'attributes', 'meta', 'downloads');

    public function __construct()
    {

    }

    public function get()
    {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
        );

        $loop = new \WP_Query($args);
        $woo_products = array();
        while ($loop->have_posts()) : $loop->the_post();
            global $product;
            $woo_product = $this->convertForApi($product);
            $woo_products[] = $woo_product;
        endwhile;

        wp_reset_query();
        return $woo_products;
    }

    public function get_by_ids(string $ids = '')
    {
        $ids = explode(',', $ids);
        $products = array();
        foreach ($ids as $id) {
            $products[$id] = $this->get_by_id($id);
        }
        return $products;
    }

    public function get_by_id(int $id = -1)
    {
        $product = wc_get_product($id);
        return $this->convertForApi($product);
    }

    public function action_on_save_product($productID)
    {
//        echo "<pre>";
//        echo "<br>productID<br>";
//        print_r($productID);
//        exit;

//        global $WPPS;
//        if ($WPPS['has_store']) {
//            $woo_product = wc_get_product(productID);
//            $api_product = $this->convertForApi($woo_product);
//
//            $Product = new Product();
//        }
    }

    public function set_meta()
    {

    }

    public function convertForApi($woo_product)
    {
        if (!$woo_product) return false;


        $id = $woo_product->get_id();
        $api_product = array();
        foreach ($this->syncer_fields as $field) {
            $value = '';
            switch ($field) {
                case 'store_product_id':
                    $value = $id;
                    break;
                case 'type':
                    $product_type = $woo_product->get_type();
                    $downloadable = $woo_product->is_downloadable() ? ', downloadable' : '';
                    $virtual = $woo_product->is_virtual() ? ', virtual' : '';
                    $value = $product_type . $downloadable . $virtual;
                    break;
                case 'published':
                    $value = ($woo_product->get_status() === 'publish') ? 1 : 0;
                    break;
                case 'is_featured':
                    $value = $woo_product->is_featured();
                    break;
                case 'date_sale_price_starts':
                    $wc_datetime = $woo_product->get_date_on_sale_from();
                    $value = isset($wc_datetime) ? $wc_datetime->date : '';
                    break;
                case 'date_sale_price_ends':
                    $wc_datetime = $woo_product->get_date_on_sale_to();
                    $value = isset($wc_datetime) ? $wc_datetime->date : '';
                    break;
                case 'in_stock':
                    $value = $woo_product->get_stock_status() === 'instock' ? 1 : 0;
                    break;
                case 'stock':
                    $value = $woo_product->get_stock_quantity();
                    break;
                case 'tags':
                    $terms = get_terms('product_tag');
                    $term_array = array();
                    if (!empty($terms) && !is_wp_error($terms)) {
                        foreach ($terms as $term) {
                            $term_array[] = $term->name;
                        }
                    }
                    $value = json_encode($term_array);
                    break;
                case 'shipping_class':
                    $value = '';
                    break;
                case 'images':
                    $image_id = $woo_product->get_image_id();
                    $value = wp_get_attachment_image_url($image_id, 'full');
                    break;
                case 'grouped_products':
                    $value = $woo_product->get_children();
                    break;
                case 'external_url':
                    $value = '';
                    break;
                case 'meta':
                    $value = '';
                    break;
                case 'downloads':
                    $value = $woo_product->get_downloads();
                    break;
                default:
                    $function_name = 'get_' . $field;
                    $value = $woo_product->$function_name();
                    break;
            }

            if (gettype($value) === "array") {
                $value = json_encode($value);
            }

            $api_product[$field] = $value;
        }
        return $api_product;
    }

    public function add($syncProduct)
    {
        $user_id = get_current_user_id();

        $woo_product_type = $syncProduct->type;
        $inStock = strtolower($syncProduct->in_stock);
        $inStock = preg_replace('/\s+/', '', $inStock);
        $soldIndividually = $syncProduct->sold_individually ? 'yes' : 'no';
        $downloadAble = 'no';
        $virtual = 'no';
        $featured = $syncProduct->is_featured;


        $post = array(
            'post_author' => $user_id,
            'post_content' => $syncProduct->description,
            'post_status' => "publish",
            'post_title' => $syncProduct->title,
            'post_parent' => '',
            'post_type' => "product",
        );


//Create post
        $product_id = wp_insert_post($post, true);
//        if ($product_id) {
//            $attach_id = get_post_meta($product->parent_id, "_thumbnail_id", true);
//            add_post_meta($product_id, '_thumbnail_id', $attach_id);
//        }

        wp_set_object_terms($product_id, 'Races', 'product_cat');
        wp_set_object_terms($product_id, $woo_product_type, 'product_type');

        update_post_meta($product_id, '_visibility', 'visible');
        update_post_meta($product_id, '_stock_status', $inStock);
        update_post_meta($product_id, 'total_sales', '0');
        update_post_meta($product_id, '_downloadable', $downloadAble);
        update_post_meta($product_id, '_virtual', $virtual);
        update_post_meta($product_id, '_regular_price', $syncProduct->regular_price);
        update_post_meta($product_id, '_sale_price', $syncProduct->sale_price);
        update_post_meta($product_id, '_purchase_note', $syncProduct->purchase_note);
        update_post_meta($product_id, '_featured', $featured);
        update_post_meta($product_id, '_weight', $syncProduct->weight);
        update_post_meta($product_id, '_length', $syncProduct->length);
        update_post_meta($product_id, '_width', $syncProduct->width);
        update_post_meta($product_id, '_height', $syncProduct->height);
        update_post_meta($product_id, '_sku', $syncProduct->sku);
//        update_post_meta($product_id, '_product_attributes', $syncProduct->attributes);
        update_post_meta($product_id, '_sale_price_dates_from', $syncProduct->date_sale_price_starts);
        update_post_meta($product_id, '_sale_price_dates_to', $syncProduct->date_sale_price_ends);
        update_post_meta($product_id, '_price', $syncProduct->regular_price);
        update_post_meta($product_id, '_sold_individually', $soldIndividually);
        update_post_meta($product_id, '_manage_stock', "no");
        update_post_meta($product_id, '_backorders', $syncProduct->backorders);
        update_post_meta($product_id, '_stock', $syncProduct->stock);

        $this->add_download_parameters($syncProduct);
        return $product_id;
    }

    public function add_download_parameters()
    {
        return true;

// file paths will be stored in an array keyed off md5(file path)
        $downdloadArray = array('name' => "Test", 'file' => $uploadDIR['baseurl'] . "/video/" . $video);

        $file_path = md5($uploadDIR['baseurl'] . "/video/" . $video);


        $_file_paths[$file_path] = $downdloadArray;
// grant permission to any newly added files on any existing orders for this product
// do_action( 'woocommerce_process_product_file_download_paths', $post_id, 0, $downdloadArray );
        update_post_meta($post_id, '_downloadable_files', $_file_paths);
        update_post_meta($post_id, '_download_limit', '');
        update_post_meta($post_id, '_download_expiry', '');
        update_post_meta($post_id, '_download_type', '');
        update_post_meta($post_id, '_product_image_gallery', '');
    }
}
