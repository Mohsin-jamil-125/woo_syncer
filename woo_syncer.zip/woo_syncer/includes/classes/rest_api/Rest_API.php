<?php

namespace Ufit\product_syncer\rest_api;

defined('ABSPATH') || exit;

class Rest_API
{
    public $success = true;
    public $message = 'Success';
    public $data = array();

    public function __construct()
    {
        add_action('rest_api_init', array($this, 'init_routes'));
    }

    public function init_routes()
    {
        register_rest_route(PRODUCT_SYNC_REST_API_URL, 'product/(?P<ids>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product_by_ids')
        ));

    }

    public function get_product_by_ids($request)
    {
        $ids = $request['ids'];
        echo "<pre>";
        echo "<br>";
        print_r($ids);
        exit;
        $Woo_Product= new Woo_Product();
        $products = $Woo_Product->get_by_ids($ids);

        $this->data = $products;
    }

}
new Rest_API;