<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

require_once 'Basic.php';
require_once __DIR__ . '/../traits/Json.php';

use Ufit\product_syncer\Basic as Basic;

class Curl extends Basic
{
    use \Ufit\product_syncer\traits\Json;

    public $payload;
    public $ch;

    public function __construct($url, $payload = null)
    {
        $headers = array(
            'Accept: application/json',
            'Content-Type: application/json',
        );

        $this->ch = curl_init($url);
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
        # Return response instead of printing.
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);

        if ($payload) {
            $payload = $this->is_json($payload) ? $payload : json_encode($payload);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, $payload);
        }
    }

    public function Cget($payload = null)
    {
        curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, 'GET');
        if ($payload) {
            $payload = $this->is_json($payload) ? $payload : json_encode($payload);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, $payload);
        }

        return $this->exee();
    }

    public function Cpost($payload = null)
    {
        curl_setopt($this->ch, CURLOPT_POST, true);
        if ($payload) {
            $payload = $this->is_json($payload) ? $payload : json_encode($payload);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, $payload);
        }
        return $this->exee();
    }

    public function exee()
    {
        # Send request.
        $result = curl_exec($this->ch);
        curl_close($this->ch);

        if ($this->is_json($result)) {
            $result = json_decode($result);
        } else {
            echo "<pre>";
            echo "Error: <br>";
            var_dump($result);
            exit();
        }

        if (!$result->success) {
            echo "<pre>";
            echo "Not success: <br>";
            var_dump($result);
            exit();
        }
        return $result;
    }
}
