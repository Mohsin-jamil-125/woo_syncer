<?php
if(!defined('PRODUCT_SYNCER_API_URL')) define('PRODUCT_SYNCER_API_URL', 'http://product_syncer.local/api/');

if(!defined('PRODUCT_SYNCER_PLUGIN_DIR')) define('PRODUCT_SYNCER_PLUGIN_DIR', '/woo-syncer/');
if(!defined('PRODUCT_SYNCER_JS_DIR')) define('PRODUCT_SYNCER_JS_DIR', PRODUCT_SYNCER_PLUGIN_DIR.'assets/js/');
if(!defined('PRODUCT_SYNCER_CSS_DIR')) define('PRODUCT_SYNCER_CSS_DIR', PRODUCT_SYNCER_PLUGIN_DIR.'assets/css/');

