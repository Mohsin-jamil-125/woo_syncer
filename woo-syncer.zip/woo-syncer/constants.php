<?php
if(!defined('PRODUCT_SYNCER_API_URL')) define('PRODUCT_SYNCER_API_URL', 'http://product_syncer.local/api/');
