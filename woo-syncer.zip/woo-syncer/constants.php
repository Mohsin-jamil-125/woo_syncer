<?php
if(!defined('PRODUCT_SYNCER_API_URL')) define('PRODUCT_SYNCER_API_URL', 'http://product_syncer.local/api/');

if(!defined('PRODUCT_SYNCER_PLUGIN_PATH')) define('PRODUCT_SYNCER_PLUGIN_PATH', plugin_dir_path( __FILE__ ));

if(!defined('PRODUCT_SYNCER_TEMPLATE_PATH')) define('PRODUCT_SYNCER_TEMPLATE_PATH', PRODUCT_SYNCER_PLUGIN_PATH.'templates/');

if(!defined('PRODUCT_SYNCER_PLUGIN_DIR')) define('PRODUCT_SYNCER_PLUGIN_DIR', '/woo-syncer/');
if(!defined('PRODUCT_SYNCER_JS_DIR')) define('PRODUCT_SYNCER_JS_DIR', PRODUCT_SYNCER_PLUGIN_DIR.'assets/js/');
if(!defined('PRODUCT_SYNCER_CSS_DIR')) define('PRODUCT_SYNCER_CSS_DIR', PRODUCT_SYNCER_PLUGIN_DIR.'assets/css/');

global $wpps;

