jQuery(document).ready(function () {
    jQuery(document).on("click", ".ufit-toggle-product-sync", function () {
        let $this = jQuery(this);
        let syncer_product_id = $this.data("productId")
        nonce = $this.data("nonce")

        jQuery.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "toggle_product_sync", syncer_product_id: syncer_product_id, nonce: nonce},
            success: function (response) {
                if (response.success) {
                    $is_sync = response.data.sync ? "Yes" : "No";
                    $this.html($is_sync)
                } else {
                    alert(response.message);
                }
            }
        })
    });

    jQuery(document).on("click", ".ufit-delete-syncer-user", function () {
        let $this = jQuery(this);
        let nonce = $this.data("nonce")

        jQuery.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "delete_syncer_user",  nonce: nonce},
            success: function (response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            }
        })
    });
});
