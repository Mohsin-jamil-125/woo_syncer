jQuery(document).ready(function () {
    jQuery(document).on("click", ".ufit-toggle-product-sync", function () {
        let $this = jQuery(this);
        product_id = $this.data("productId")
        nonce = $this.data("nonce")

        jQuery.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "toggle_product_sync", product_id: product_id, nonce: nonce},
            success: function (response) {
                if (response.success) {
                    $is_sync = response.data.sync ? "Yes" : "No";
                    $this.html($is_sync)
                } else {
                    alert(response.message);
                }
            }
        })
    });
});
