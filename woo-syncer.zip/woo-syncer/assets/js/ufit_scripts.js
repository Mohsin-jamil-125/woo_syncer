jQuery(document).ready(function () {
    const $ = jQuery;
    $(document).on("click", ".ufit-toggle-product-sync", function () {
        let $this = $(this);
        let syncer_product_id = $this.data("productId")
        nonce = $this.data("nonce")

        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "toggle_product_sync", syncer_product_id: syncer_product_id, nonce: nonce},
            success: function (response) {
                if (response.success) {
                    $is_sync = response.data.sync ? "Yes" : "No";
                    $this.html($is_sync)
                } else {
                    alert(response.message);
                }
            }
        })
    });

    $(document).on("click", ".ufit-delete-syncer-user", function () {
        let $this = $(this);
        let nonce = $this.data("nonce")

        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: {action: "delete_syncer_user", nonce: nonce},
            success: function (response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.message);
                }
            }
        })
    });

    $(document).on("click", ".ufit-show-store-products", function () {
        let $this = $(this);
        let storeId = $this.data("storeId");
        let nonce = $this.data("nonce");

        let data = {action: "get_source_products", nonce: nonce, "storeId": storeId};
        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: data,
            success: function (response) {
                if (response.success) {
                    let data = response.data;
                    let products = data.data;
                    let HTML = "";
                    products.forEach(function (product, index) {
                        HTML += '<tr>';
                        HTML += `<td scope="col">${index}</td>`;
                        HTML += `<td scope="col">${product.title}</td>`;
                        HTML += `<td scope="col">${product.sku}</td>`;
                        HTML += `<td scope="col" style="width: 92px"><img src="${product.images_url}" alt="${product.title}" class="img-thumbnail"></td>`;
                        HTML += `<td scope="col">
                                    <button class="btn btn-info ufit-add-product" data-nonce="${ufit.addProductNonce}" data-product-id="${product.id}">Add</button>
                                  </td>`;
                        HTML += '</tr>';
                    });
                    $("#ufit-source-products-model").find("tbody").html(HTML);
                    $("#ufit-source-products-model").modal("show");
                } else {
                    alert(response.message);
                }
            }
        })
    });

    $(document).on("click", ".ufit-add-product", function () {
        let $this = $(this);
        let productIds = $this.data("productId");
        let nonce = $this.data("nonce");

        let data = {action: "add_source_products", nonce: nonce, "productIds": productIds};
        $.ajax({
            type: "post",
            dataType: "json",
            url: ufit.ajaxurl,
            data: data,
            success: function (response) {
                if (response.success) {
                    let data = response.data;
                } else {
                    alert(response.message);
                }
            }
        });
    });
});
