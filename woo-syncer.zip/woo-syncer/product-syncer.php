<?php
/**
 * Plugin Name: Product Syncer
 * Plugin URI:
 * Description: TABC.
 * Version: 1.0.0
 * Author: Uforia Infotech
 * Author URI:
 **/

require_once 'constants.php';
require_once 'includes/classes/Syncer_Store.php';
require_once 'includes/classes/Syncer_Product.php';
require_once 'includes/classes/Curl.php';
require_once 'includes/classes/Woo_Product.php';
require_once 'includes/classes/Basic.php';
require_once 'includes/classes/Ajax_Controller.php';

use Ufit\product_syncer\Syncer_Product as Syncer_Product;
use Ufit\product_syncer\Syncer_Store as Syncer_Store;

class Product_Syncer
{
    public $version = 1.0;

    function __construct()
    {
        add_action('admin_init', array($this, 'admin_init'));
        add_action('init', array($this, 'action_init'));
        add_action('admin_menu', array($this, 'admin_menu'));
    }

    public function admin_init()
    {
        $this->register_settings();
    }

    public function action_init()
    {
        $this->script_enqueuer();
        $this->style_enqueuer();

    }

    private function script_enqueuer()
    {
        wp_register_script("ufit_script", WP_PLUGIN_URL.PRODUCT_SYNCER_JS_DIR . 'ufit_scripts.js', array('jquery'));
        wp_localize_script('ufit_script', 'ufit', array('ajaxurl' => admin_url('admin-ajax.php')));

        wp_enqueue_script('jquery');
        wp_enqueue_script('ufit_script');

        wp_register_script('ufit_bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js');
        wp_enqueue_script('ufit_bootstrap');
    }

    private function style_enqueuer()
    {
        wp_register_script("ufit_style", WP_PLUGIN_URL.PRODUCT_SYNCER_CSS_DIR . 'ufit_style.css');
        wp_enqueue_script('ufit_style');

        wp_register_style('ufit_bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css');
        wp_enqueue_style('ufit_bootstrap');
    }

    /**
     * Register a menu page.
     */
    public function admin_menu()
    {
        $Syncer_Product = new Syncer_Product();
        add_menu_page(
            __('Product Syncer', 'textdomain'),
            __('Product Syncer', 'textdomain'),
            'manage_options',
            'product-syncer',
            array($this, 'render_option_page'),
            '',
            6
        );
        add_submenu_page(
            'product-syncer',
            __('Products', 'textdomain'),
            __('Products', 'textdomain'),
            'manage_options',
            'product-syncer-products',
            array($Syncer_Product, 'list'),
        );
    }

    public function render_option_page()
    {
        $options = get_option('product_syncer');
        $store_is = isset($options['store_is']) ?? '';
        $Syner_Store = new Syncer_Store();
        $store_key = $Syner_Store->getKey() ?? '';
        include_once 'templates/options.php';
    }

    public function register_settings()
    {
        register_setting('product_syncer', 'product_syncer', array($this, 'product_syncer_options_validate'));
        add_settings_section('syncer_settings_section', 'Product Syncer Settings', array($this, 'dbi_plugin_section_text'), 'syncer_setting_page');
    }


    function dbi_plugin_section_text()
    {
        echo '';
    }

    public function product_syncer_options_validate($input)
    {
        $attr = array(
            'type' => $input['store_is']
        );

        $syncer_store = new Syncer_Store($attr);
        $syncer_key = $syncer_store->getKey();

        if ($syncer_key === "") {
            $response = $syncer_store->add();
            $syncer_key = $response->key;
        }

        $syncer_type = $input['store_is'];
        switch ($syncer_type) {
            case 'destination':
                break;
            case 'source':
                $properties = array(
                    'syncer_key'  => $syncer_key,
                    'syncer_type' => $syncer_type,
                );
                $syncer_product = new Syncer_Product($properties);
                $response = $syncer_product->add();
                break;
        }

        return $input;
    }

    public function add_vedor()
    {

    }
}

new Product_Syncer();
