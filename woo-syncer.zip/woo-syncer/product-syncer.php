<?php
/**
 * Plugin Name: Product Syncer
 * Plugin URI:
 * Description: TABC.
 * Version: 1.0
 * Author: Uforia Infotech
 * Author URI:
 **/

require_once 'constants.php';
require_once 'includes/classes/Syncer_Store.php';
require_once 'includes/classes/Syncer_Product.php';
require_once 'includes/classes/Curl.php';
require_once 'includes/classes/Woo_Product.php';
require_once 'includes/classes/Basic.php';
//require_once 'includes/traits/Json.php';

use Ufit\product_syncer\Syncer_Store as Syncer_Store;
use Ufit\product_syncer\Syncer_Product as Syncer_Product;
use Ufit\product_syncer\Curl as Curl;
use Ufit\product_syncer\Woo_Product as Woo_Product;

class Product_Syncer
{
    public $version = 1.0;

    function __construct()
    {
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'admin_menu'));
    }

    public function admin_init()
    {
        $this->register_settings();
    }

    /**
     * Register a menu page.
     */
    public function admin_menu()
    {
        add_menu_page(
            __('Product Syncer', 'textdomain'),
            'Product Syncer',
            'manage_options',
            'product-syncer',
            array($this, 'render_option_page'),
            '',
            6
        );
    }

    public function render_option_page()
    {
        include_once 'templates/options.php';
    }

    public function register_settings()
    {
        register_setting('product_syncer', 'product_syncer', array($this, 'product_syncer_options_validate'));
        add_settings_section('syncer_settings_section', 'Product Syncer Settings', array($this, 'dbi_plugin_section_text'), 'syncer_setting_page');
    }


    function dbi_plugin_section_text()
    {
        echo '';
    }

    public function product_syncer_options_validate($input)
    {
        $attr = array(
            'type' => $input['store_is']
        );

        $syncer_store = new Syncer_Store($attr);
        $syncer_key = $syncer_store->getKey();

        if ($syncer_key === "") {
            $response = $syncer_store->add();
            $syncer_key = $response->key;
        }

        $syncer_type = $input['store_is'];
        switch ($syncer_type) {
            case 'destination':
                break;
            case 'source':
                $properties = array(
                    'syncer_key' => $syncer_key,
                    'syncer_type' => $syncer_type,
                );
                $syncer_product = new Syncer_Product($properties);
                $response = $syncer_product->add();
                break;
        }

        return $input;
    }

    public function add_vedor()
    {

    }
}

new Product_Syncer();
