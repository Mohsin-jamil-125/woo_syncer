<?php
/**
 * Plugin Name: Product Syncer
 * Plugin URI:
 * Description: TABC.
 * Version: 1.0.0
 * Author: Uforia Infotech
 * Author URI:
 **/

/**
 * boolen
 */
global $hasSyncerStore;

require_once 'constants.php';
require_once 'includes/classes/Syncer_Store.php';
require_once 'includes/classes/Syncer_Product.php';
require_once 'includes/classes/Curl.php';
require_once 'includes/classes/Woo_Product.php';
require_once 'includes/classes/Basic.php';
require_once 'includes/classes/Ajax_Controller.php';

use Ufit\product_syncer\Syncer_Product as Syncer_Product;
use Ufit\product_syncer\Syncer_Store as Syncer_Store;
use Ufit\product_syncer\Woo_Product as Woo_Product;

class Product_Syncer
{
    public $version = 1.0;

    function __construct()
    {
        add_action('admin_init', array($this, 'admin_init'));
        add_action('init', array($this, 'action_init'));
        add_action('admin_menu', array($this, 'admin_menu'));
    }

    public function admin_init()
    {
        $this->register_settings();

        global $hasSyncerStore;

        $Syncer_Store = new Syncer_Store;
        $hasSyncerStore = $Syncer_Store->has();
        if($hasSyncerStore){
            $this->bindSyncerHoocks();
        }
    }

    public function bindSyncerHoocks(){
        $Woo_Product = new Woo_Product();
        add_action("save_post_product", array($Woo_Product, "action_on_save_product"));
    }

    public function action_init()
    {
        $this->script_enqueuer();
        $this->style_enqueuer();

    }

    private function script_enqueuer()
    {
        wp_register_script("ufit_script", WP_PLUGIN_URL . PRODUCT_SYNCER_JS_DIR . 'ufit_scripts.js', array('jquery'));
        wp_localize_script('ufit_script', 'ufit', array('ajaxurl' => admin_url('admin-ajax.php')));

        wp_enqueue_script('jquery');
        wp_enqueue_script('ufit_script');

        wp_register_script('ufit_bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js');
        wp_enqueue_script('ufit_bootstrap');
    }

    private function style_enqueuer()
    {
        wp_register_script("ufit_style", WP_PLUGIN_URL . PRODUCT_SYNCER_CSS_DIR . 'ufit_style.css');
        wp_enqueue_script('ufit_style');

        wp_register_style('ufit_bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css');
        wp_enqueue_style('ufit_bootstrap');
    }

    /**
     * Register a menu page.
     */
    public function admin_menu()
    {
        $Syncer_Store = new Syncer_Store();
        $Syncer_Product = new Syncer_Product();
        add_menu_page(
            __('Product Syncer', 'textdomain'),
            __('Product Syncer', 'textdomain'),
            'manage_options',
            'product-syncer',
            array($this, 'render_option_page'),
            '',
            6
        );
        if($Syncer_Store->has()){
            switch ($Syncer_Store->type){
                case 'source':
                    add_submenu_page(
                        'product-syncer',
                        __('Products', 'textdomain'),
                        __('Products', 'textdomain'),
                        'manage_options',
                        'product-syncer-products',
                        array($Syncer_Product, 'list'),
                    );
                    break;
                case 'destination':
                    add_submenu_page(
                        'product-syncer',
                        __('Stores', 'textdomain'),
                        __('Stores', 'textdomain'),
                        'manage_options',
                        'product-syncer-stores',
                        array($Syncer_Store, 'list'),
                    );
                    break;
            }
        }
    }

    public function render_option_page()
    {
        include_once 'templates/options.php';
    }

    public function register_settings()
    {
        register_setting('product_syncer', 'product_syncer', array($this, 'product_syncer_options_validate'));
        add_settings_section('syncer_settings_section', 'Product Syncer Settings', array($this, 'dbi_plugin_section_text'), 'syncer_setting_page');
    }


    function dbi_plugin_section_text()
    {
        echo '';
    }

    public function product_syncer_options_validate($input)
    {
        global $hasSyncerStore;

        $syncer_type = $input['store_is'];
        $attr = array(
            'type' => $syncer_type
        );

        $syncer_store = new Syncer_Store($attr);
        if(!$hasSyncerStore){
            $response = $syncer_store->add();
            $this->bindSyncerHoocks();
        }

        switch ($syncer_type) {
            case 'destination':
                // Do something
                break;
            case 'source':
                // Do something
                break;
        }
        return $input;
    }

    public function add_vedor()
    {

    }
}

new Product_Syncer();
