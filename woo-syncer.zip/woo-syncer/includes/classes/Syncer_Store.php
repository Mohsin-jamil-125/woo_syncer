<?php
namespace Ufit\product_syncer;

use ufit_ps_curl as Curl;

class Syncer_Store
{

    private $wp_user;
    private $type;

    public function __construct(Array $properties=array())
    {
        $this->wp_user = wp_get_current_user();
        foreach($properties as $key => $value){
            $this->{$key} = $value;
        }
    }

    public function add()
    {
        $data = array(
            'type' => $this->type
        );

        $curl = NEW Curl(PRODUCT_SYNCER_API_URL.'stores');
        $response = $curl->Cpost(json_encode($data));

        if($response->success){
            $data = $response->data;
            update_user_meta($this->wp_user->ID, 'ufit_syncer_store_key', $data->key);
            update_user_meta($this->wp_user->ID, 'ufit_syncer_store_type', $this->type);
        }else{

        }
        return $data;
    }

    public function get()
    {

    }

    public function update()
    {

    }

    public function has()
    {
        return get_user_meta($this->wp_user->ID, 'ufit_syncer_store_key', true) !== "";
    }

    public function getKey()
    {
        return get_user_meta($this->wp_user->ID, 'ufit_syncer_store_key', true);
    }


}
