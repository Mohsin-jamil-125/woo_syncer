<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

//require_once 'Curl.php';
use Ufit\product_syncer\Curl as Curl;

class Syncer_Store
{
    private $wp_user;
    public $type;
    public $meta_key = 'ufit_syncer_store_key';
    private $key;

    public function __construct(array $properties = array())
    {
        $this->wp_user = wp_get_current_user();
        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }

        $this->key = get_user_meta($this->wp_user->ID, $this->meta_key, true);

        $options = get_option('product_syncer');
        $this->type = $options['store_is'] ??  '';
    }

    public function add()
    {
        $data = array(
            'type' => $this->type
        );

        $curl = new Curl(PRODUCT_SYNCER_API_URL . 'stores');
        $response = $curl->Cpost(json_encode($data));

        if ($response->success) {
            global $hasSyncerStore;
            $hasSyncerStore = true;

            $data = $response->data;
            $this->key = $data->key;

            update_user_meta($this->wp_user->ID, $this->meta_key, $this->key);
            update_user_meta($this->wp_user->ID, 'ufit_syncer_store_type', $this->type);

            switch ($this->type) {
                case 'destination':
                    break;
                case 'source':
                    $properties = array(
                        'syncer_key'  => $this->key,
                    );
                    $syncer_product = new Syncer_Product($properties);
                    $syncer_product->push_all();
                    break;
            }
        } else {

        }
        return $data;
    }

    public function list()
    {
        $paged = $_GET['paged'] ?? 1;

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->key . '/products/10?page=' . $paged);
        $product_data = $ch->Cget(json_encode(array()))->data;

        $properties = array('product_data' => $product_data);
        $drafts_table = new Syncer_Product_List($properties);
        ?>
        <div class="wrap">
            <h2><?php esc_html_e('All Products List', 'product-syncer'); ?></h2>
            <form id="all-drafts" method="get">
                <input type="hidden" name="page" value="product-syncer-products"/>

                <?php
                $drafts_table->prepare_items();
                $drafts_table->search_box('Search', 'search');
                $drafts_table->display();
                ?>
            </form>
        </div>
        <?php



    }

    public function update()
    {

    }

    public function has()
    {
        return $this->key !== "";
    }

    public function getKey()
    {
        return $this->key;
    }


}
