<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

require_once 'Syncer_DB.php';

use Ufit\product_syncer\Curl as Curl;
use Ufit\product_syncer\Syncer_DB as Syncer_DB;

class Syncer_Store
{
    private $wp_user;

    public $name;
    public $type;
    private $key = '';
    private $id = -1;
    public $isActive;

    public $meta = array(
        'key'  => 'ufit_syncer_store_key',
        'type' => 'ufit_syncer_store_type',
    );

    public function __construct(array $properties = array())
    {
        $this->wp_user = wp_get_current_user();

        $Syncer_DB = new Syncer_DB();
        $selfStrore = $Syncer_DB->get_self_store();

        if ($selfStrore) {
            $this->id = $selfStrore->ID;
            $response = $this->get_by_id();

            if ($response->success) {
                $store = $response->data;
                $this->set($store);
            } else {
                // error handaling
            }
        } else {
            // error handaling
        }

        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }
    }

    public function set($store)
    {
        $this->id = $store->id;
        $this->name = $store->name;
        $this->type = $store->type;
        $this->key = $store->key;
        $this->isActive = $store->is_active;
    }

    public function self_list()
    {
        include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'stores/self/index.php';
    }

    public function import_list()
    {
        $resopnse = $this->get_sources();
        if ($resopnse->success) {
            $stores = $resopnse->data;
            include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'stores/import/index.php';
        }
    }

    public function get_sources()
    {
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->id . '/sources');
        return $ch->Cget();
    }

    public function get_source_products($storId)
    {
        $ch = new Curl(PRODUCT_SYNCER_API_URL . "sourcestore/$storId/products/sync");
        return $ch->Cget();
    }

    public function add_source_products($storIds)
    {
        $payload = array('storIds' => $storIds);
        $ch = new Curl(PRODUCT_SYNCER_API_URL . "sourcestore/$storId/products/sync");
        return $ch->Cpost($payload);
    }

    public function get_by_id()
    {
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'stores/' . $this->id);
        return $ch->Cget();
    }

    public function create()
    {
        include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'stores/import/create.php';
    }

    public function add_source()
    {
        $key = $_POST['source_store_key'];
        $response = $this->add_to_server($key);

        if ($response->success) {
            $source_store = $response->data;
            $this->set($source_store);

            $dbData = array(
                'ID'         => $this->id,
                'unique_key' => $this->key,
                'behave_as'  => 'import',
            );

            $Syncer_DB = new Syncer_DB();
            $Syncer_DB->insert_store($dbData);
            wp_redirect(admin_url('admin.php?page=product-syncer-stores'));
        } else {
            // error handaling
        }
    }

    public function add_to_server($key)
    {
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->id . '/sync/' . $key);
        return $ch->Cpost(array());
    }

    public function get_by_key()
    {
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->key);
        return $ch->Cget();
    }

    public function add()
    {
        $payload = array(
            'type'  => $this->type,
            'title' => $this->name
        );

        $curl = new Curl(PRODUCT_SYNCER_API_URL . 'stores');
        $response = $curl->Cpost($payload);

        if ($response->success) {
            global $PS;
            $PS['has_store'] = true;

            $data = $response->data;
            $this->key = $data->key;

            $dbData = array(
                'ID'         => $data->id,
                'unique_key' => $this->key,
                'behave_as'  => 'itself',
            );

            $Syncer_DB = new Syncer_DB();
            $Syncer_DB->insert_store($dbData);

            switch ($this->type) {
                case 'destination':
                    break;
                case 'source':
                    $properties = array(
                        'syncer_key' => $this->key,
                    );
                    $syncer_product = new Syncer_Product($properties);
                    $syncer_product->push_all();
                    break;
            }
        } else {

        }
        return $data;
    }

    public function update()
    {

    }

    public function has()
    {
        return $this->key !== '';
    }

    public function getKey()
    {
        return $this->key;
    }

    public function delete()
    {

    }
}
