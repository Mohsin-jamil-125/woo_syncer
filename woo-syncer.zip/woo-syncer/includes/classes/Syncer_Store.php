<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

//require_once 'Curl.php';
use Ufit\product_syncer\Curl as Curl;

class Syncer_Store
{
    private $wp_user;
    public $type;
    private $key;

    public $meta = array(
        'key'  => 'ufit_syncer_store_key',
        'type' => 'ufit_syncer_store_type',
    );

    public function __construct(array $properties = array())
    {
        $this->wp_user = wp_get_current_user();

        $this->key = get_user_meta($this->wp_user->ID, $this->meta['key'], true);

        $options = get_option('product_syncer');
        $this->type = $options['store_is'] ?? '';

        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }
    }

    public function list()
    {
        global $wpdb;
        $tablename = $wpdb->prefix . 'ps_user_syncer_store';
        $user_id = $this->wp_user->ID;
        $sql = "SELECT * FROM $tablename WHERE `user_id` = $user_id";
        $store_ids = $wpdb->get_results($sql);
//        $response = $this->get_by_ids($store_ids);
        $tores = $store_ids;
        include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'stores/index.php';
    }

    public function get_by_ids($ids)
    {
        $payload = array('ids' => $ids);
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'stores/', $payload);
        return $ch->Cget();
    }

    public function create()
    {
        include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'stores/create.php';
    }

    public function add_source()
    {
        $this->key = $_POST['source_store_key'];
        $response = $this->get_by_key();

        if ($response->success) {
            $id = $response->data->id;
        }

        // insert in WP database

        global $wpdb;
        $tablename = $wpdb->prefix . 'ps_user_syncer_store';
        $wpdb->insert($tablename, array(
            'user_id'         => $this->wp_user->ID,
            'syncer_store_id' => $id,
        ));


        wp_redirect(admin_url('admin.php?page=product-syncer-stores'));
    }

    public function get_by_key()
    {
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->key);
        return $ch->Cget();
    }

    public function add()
    {
        $payload = array(
            'type' => $this->type
        );

        $curl = new Curl(PRODUCT_SYNCER_API_URL . 'stores');
        $response = $curl->Cpost($payload);

        if ($response->success) {
            global $PS;
            $PS['has_store'] = true;

            $data = $response->data;
            $this->key = $data->key;

            update_user_meta($this->wp_user->ID, $this->meta['key'], $this->key);
            update_user_meta($this->wp_user->ID, $this->meta['type'], $this->type);

            switch ($this->type) {
                case 'destination':
                    break;
                case 'source':
                    $properties = array(
                        'syncer_key' => $this->key,
                    );
                    $syncer_product = new Syncer_Product($properties);
                    $syncer_product->push_all();
                    break;
            }
        } else {

        }
        return $data;
    }

    public function update()
    {

    }

    public function has()
    {
        return $this->key !== "";
    }

    public function getKey()
    {
        return $this->key;
    }

    public function delete()
    {
        $this->key = delete_user_meta($this->wp_user->ID, $this->meta['key']);
        $this->key = delete_user_meta($this->wp_user->ID, $this->meta['type']);
    }
}
