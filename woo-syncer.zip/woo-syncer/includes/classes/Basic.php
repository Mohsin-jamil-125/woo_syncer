<?php


namespace Ufit\product_syncer;


class Basic
{

}
