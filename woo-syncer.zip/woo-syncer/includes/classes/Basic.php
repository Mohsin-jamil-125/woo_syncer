<?php


namespace Ufit\product_syncer;

defined( 'ABSPATH' ) || exit;

class Basic
{

}
