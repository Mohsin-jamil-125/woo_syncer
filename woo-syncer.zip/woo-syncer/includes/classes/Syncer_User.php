<?php
namespace Ufit\product_syncer;

defined( 'ABSPATH' ) || exit;
class Syncer_User
{
    private $wp_user;
    private $syncer_user;

    public function __construct()
    {
        $this->wp_user = wp_get_current_user();
    }

    public function add()
    {
        echo '<br><br>***********234234******************<br><pre>';
        require_once 'Syncer_Role.php';

        $syncer_role = new Syncer_Role();

        $jsonArrayResponse = $syncer_role->get();

        print_r($jsonArrayResponse);
        echo '</pre>';
        exit();
    }

    public function get()
    {

    }

    public function update()
    {

    }

    public function hasUser()
    {
        $syncer_key = get_user_meta($this->wp_user->ID, 'ufit_syncer_key', true);
        return $syncer_key !== '';
    }


}
