<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

require_once 'Syncer_Store.php';
require_once 'Syncer_DB.php';
require_once 'Syncer_Role.php';
require_once 'Curl.php';

use Ufit\product_syncer\Curl as Curl;
use Ufit\product_syncer\Syncer_Store as Syncer_Store;
use Ufit\product_syncer\Syncer_DB as Syncer_DB;

class Syncer_User
{
    private $wp_user;
    private $token = '';
    public $type;

    public $tableName = '';

    private $meta = array(
        'token' => 'ufit_syncer_user_token',
        'type'  => 'ufit_syncer_user_type'
    );

    public function __construct(array $properties = array())
    {
        $this->wp_user = wp_get_current_user();

        $Syncer_DB = new Syncer_DB();
        $this->token = $Syncer_DB->get_user_token();

        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }
    }

    public function add()
    {
        $role = $this->type === 'source' ? 'Vendor' : 'Marketer';
        $payload = array(
            'name'       => $this->wp_user->user_nicename,
            'email'      => $this->wp_user->user_nicename . time() . '@gmail.com',
            'password'   => '12345678',
            'c_password' => '12345678',
            'roles'      => $role
        );

        $Curl = new Curl(PRODUCT_SYNCER_API_URL . 'register');
        $response = $Curl->Cpost($payload);

        if ($response->success) {
            $data = $response->data;
            $this->token = $data->token;

            $dbData = array(
                'token' => $this->token,
            );
            $Syncer_DB = new Syncer_DB();
            $Syncer_DB->inset_user($dbData);
        }
    }

    public function get()
    {

    }

    public function update()
    {

    }

    public function has()
    {
        return $this->token !== '';
    }

    public function get_token()
    {
        return $this->token;
    }

    public function delete()
    {
        $to_return = array(
            'success' => true,
            'message' => 'Delete Successfully'
        );

        $this->key = delete_user_meta($this->wp_user->ID, $this->meta['token']);
        $this->key = delete_user_meta($this->wp_user->ID, $this->meta['type']);

        delete_option('product_syncer');

        $Syncer_Store = new Syncer_Store;
        $Syncer_Store->delete();
        return $to_return;
    }
}
