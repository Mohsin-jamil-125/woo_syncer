<?php

namespace Ufit\product_syncer;

defined( 'ABSPATH' ) || exit;

require_once 'Syncer_Product.php';

use Ufit\product_syncer\Syncer_Product as Syncer_Product;

class Ajax_Controller extends Basic
{
    private $success = 'true';
    private $message = '';
    private $data = array();

    public function __construct()
    {
        add_action("wp_ajax_toggle_product_sync", array($this, "toggle_product_sync"));
    }

    public function toggle_product_sync()
    {
        if (!wp_verify_nonce($_REQUEST['nonce'], "toggle_product_sync_nonce")) {
            exit("No naughty business please");
        }

        $wooProductId = $_REQUEST['product_id'];
        $Syncer_Product = new Syncer_Product();
        $response = $Syncer_Product->toggle_sync($wooProductId);
//        $this->set($response);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            $result = json_encode($response);
            echo $result;
        } else {
            header("Location: " . $_SERVER["HTTP_REFERER"]);
        }
        die();
    }

    private function set(array $properties = array())
    {
        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }
    }

    function must_login()
    {
        echo "You must log in";
        die();
    }
}

new Ajax_Controller();
