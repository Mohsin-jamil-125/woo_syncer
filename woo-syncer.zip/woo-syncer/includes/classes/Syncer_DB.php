<?php


namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

class Syncer_DB
{

    public $db_version_key = 'ps_db_version';
    public $db_version_value = '1.0.0';

    public function __construct()
    {
    }

    public function create_tables()
    {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        global $wpdb, $PS;

        $charset_collate = $wpdb->get_charset_collate();

        // create stores table
        $table_name = $wpdb->prefix . $PS['table_prefix'] . "stores";
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {

            $sql = "CREATE TABLE $table_name (
    `ID` bigint(20) NOT NULL,
  `unique_key` varchar(255) COLLATE latin1_bin NOT NULL,
  `type` varchar(255) COLLATE latin1_bin NOT NULL COMMENT 'self, import',
            PRIMARY KEY  (ID)
    ) $charset_collate;";
            dbDelta($sql);
        }

        // create users table
        $table_name = $wpdb->prefix . $PS['table_prefix'] . "users";
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            $sql = "CREATE TABLE $table_name (
  `ID` bigint(20) NOT NULL,
  `token` longtext COLLATE latin1_bin NOT NULL,
            PRIMARY KEY  (ID)
    ) $charset_collate;";
            dbDelta($sql);
        }

        // create user_store table
        $table_name = $wpdb->prefix . $PS['table_prefix'] . "user_store";
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            $sql = "CREATE TABLE $table_name (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `syncer_user_id` bigint(20) NOT NULL,
  `syncer_store_id` bigint(20) NOT NULL,
            PRIMARY KEY  (ID)
    ) $charset_collate;";
            dbDelta($sql);
        }
        
        add_option($this->db_version_key, $this->db_version_value);

    }

}
