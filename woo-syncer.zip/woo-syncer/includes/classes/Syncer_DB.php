<?php


namespace Ufit\product_syncer;

defined('ABSPATH') || exit;

class Syncer_DB
{

    public $db_version_key = 'ps_db_version';
    public $db_version_value = '1.0.0';
    public $table_name = array();

    public function __construct()
    {
        global $wpdb, $PS;
        $table_prefix = $wpdb->prefix . $PS['table_prefix'];
        $this->table_name = array(
            'stores'     => $table_prefix . "stores",
            'users'      => $table_prefix . "users",
            'user_store' => $table_prefix . "user_store",
        );
    }

    public function create_tables()
    {
        // if db version not change
        if (get_option($this->db_version_key) === $this->db_version_value) {
            return false;
        }

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        global $wpdb, $PS;

        $charset_collate = $wpdb->get_charset_collate();

        // create stores table
        $table_name = $this->table_name['stores'];
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {

            $sql = "CREATE TABLE $table_name (
    `ID` bigint(20) NOT NULL,
  `unique_key` varchar(255) COLLATE latin1_bin NOT NULL,
  `behave_as` varchar(255) COLLATE latin1_bin NOT NULL COMMENT 'itself, import',
            PRIMARY KEY  (ID)
    ) $charset_collate;";
            dbDelta($sql);
        }

        // create users table
        $table_name = $this->table_name['users'];
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            $sql = "CREATE TABLE $table_name (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` longtext COLLATE latin1_bin NOT NULL,
            PRIMARY KEY  (ID)
    ) $charset_collate;";
            dbDelta($sql);
        }

        // create user_store table
        $table_name = $this->table_name["user_store"];
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            $sql = "CREATE TABLE $table_name (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `syncer_user_id` bigint(20) NOT NULL,
  `syncer_store_id` bigint(20) NOT NULL,
            PRIMARY KEY  (ID)
    ) $charset_collate;";
            dbDelta($sql);
        }

        // update DB version
        add_option($this->db_version_key, $this->db_version_value);
        return false;
    }

    public function get_user_token()
    {
        global $wpdb;
        $table_name = $this->table_name['users'];
        $token = $wpdb->get_row("SELECT `token` FROM $table_name");
        $token = $token ? $token->token : '';
        return $token;
    }

    public function inset_user($data)
    {
        global $wpdb;
        $table_name = $this->table_name['users'];
        $wpdb->insert($table_name, $data);
    }

    // Store Table
    public function insert_store($data)
    {
        global $wpdb;
        $table_name = $this->table_name['stores'];
        $wpdb->insert($table_name, $data);
    }

    public function get_self_store()
    {
        global $wpdb;
        $table_name = $this->table_name['stores'];
        $sql = "SELECT * FROM $table_name WHERE `behave_as` LIKE 'itself'";
        return $wpdb->get_row($sql);
    }

    public function get_import_stores()
    {
        global $wpdb;
        $table_name = $this->table_name['stores'];
        $sql = "SELECT * FROM $table_name WHERE `behave_as` LIKE 'import'";
        return $wpdb->get_results($sql);
    }


}
