<?php
namespace Ufit\product_syncer;

defined( 'ABSPATH' ) || exit;
class Woo_Product
{
    public $syncer_fields = array('store_product_id', 'type', 'sku', 'name', 'published', 'is_featured', 'catalog_visibility', 'short_description', 'description', 'date_sale_price_starts', 'date_sale_price_ends', 'tax_status', 'tax_class', 'in_stock', 'stock', 'backorders', 'sold_individually', 'weight', 'length', 'width', 'height', 'reviews_allowed', 'purchase_note', 'sale_price', 'regular_price', 'categories', 'tags', 'shipping_class', 'images', 'download_limit', 'download_expiry', 'parent_id', 'grouped_products', 'external_url', 'attributes', 'meta', 'downloads');

    public function __construct()
    {

    }

    public function get()
    {
        $args = array(
            'post_type'      => 'product',
            'posts_per_page' => -1,
        );

        $loop = new \WP_Query($args);
        $woo_products = array();
        while ($loop->have_posts()) : $loop->the_post();
            global $product;
            $id = $product->get_id();

            $woo_product = array();
            foreach ($this->syncer_fields as $field) {
                $value = '';
                switch ($field) {
                    case 'store_product_id':
                        $value = $id;
                        break;
                    case 'type':
                        $product_type = $product->get_type();
                        $downloadable = $product->is_downloadable() ? ', downloadable' : '';
                        $virtual = $product->is_virtual() ? ', virtual' : '';
                        $value = $product_type . $downloadable . $virtual;
                        break;
                    case 'published':
                        $value = ($product->get_status() === 'publish') ? 1 : 0;
                        break;
                    case 'is_featured':
                        $value = $product->is_featured();
                        break;
                    case 'date_sale_price_starts':
                        $wc_datetime = $product->get_date_on_sale_from();
                        $value = isset($wc_datetime) ? $wc_datetime->date : '';
                        break;
                    case 'date_sale_price_ends':
                        $wc_datetime = $product->get_date_on_sale_to();
                        $value = isset($wc_datetime) ? $wc_datetime->date : '';
                        break;
                    case 'in_stock':
                        $value = $product->get_stock_status() === 'instock' ? 1 : 0;
                        break;
                    case 'stock':
                        $value = $product->get_stock_quantity();
                        break;
                    case 'tags':
                        $terms = get_terms('product_tag');
                        $term_array = array();
                        if (!empty($terms) && !is_wp_error($terms)) {
                            foreach ($terms as $term) {
                                $term_array[] = $term->name;
                            }
                        }

                        $value = json_encode($term_array);
                        break;
                    case 'shipping_class':
                        $value = '';
                        break;
                    case 'images':
                        $image_id = $product->get_image_id();
                        $value = wp_get_attachment_image_url($image_id, 'full');
                        break;
                    case 'grouped_products':
                        $value = $product->get_children();
                        break;
                    case 'external_url':
                        $value = '';
                        break;
                    case 'meta':
                        $value = '';
                        break;
                    case 'downloads':
                        $value = $product->get_downloads();
                        break;
                    default:
                        $function_name = 'get_' . $field;
                        $value = $product->$function_name();
                        break;
                }

                if(gettype($value) === "array"){
                    $value = json_encode($value);
                }

                $woo_product[$field] = $value;
            }

            $woo_products[] = $woo_product;

        endwhile;

        wp_reset_query();
        return $woo_products;
    }
}
