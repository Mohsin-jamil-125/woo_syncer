<?php
namespace Ufit\product_syncer;

defined( 'ABSPATH' ) || exit;
class Syncer_Role{

    public function get(){
        $cURLConnection = curl_init();
        curl_setopt($cURLConnection, CURLOPT_URL, PRODUCT_SYNCER_API_URL.'roles');
        curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
        $return = curl_exec($cURLConnection);
        curl_close($cURLConnection);
        return json_decode($return);
    }
}
