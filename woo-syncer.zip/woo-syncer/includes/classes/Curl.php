<?php

namespace Ufit\product_syncer;

require_once 'Basic.php';
require_once __DIR__.'/../traits/Json.php';

use Ufit\product_syncer\Basic as Basic;

class Curl extends Basic
{
    use \Ufit\product_syncer\traits\Json;

    public $payload;
    public $ch;

    public function __construct($url)
    {
        $this->ch = curl_init($url);
    }

    public function Cget()
    {

    }

    public function Cpost($payload)
    {
        # Setup request to send json via POST.
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        # Return response instead of printing.
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        # Send request.
        $result = curl_exec($this->ch);
        curl_close($this->ch);

        if($this->is_json($result)){
            $result = json_decode($result);
        }else{
            print_r($result);
            exit();
        }

        if (!$result->success){
            // error handling
        }
        return $result;
    }
}
