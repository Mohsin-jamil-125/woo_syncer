<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;
require_once 'Basic.php';
require_once 'Syncer_Product_List.php';
require_once 'Syncer_Store.php';

use Ufit\product_syncer\Basic as Basic;
use Ufit\product_syncer\Syncer_Product_List as Syncer_Product_List;
use Ufit\product_syncer\Syncer_Store as Syncer_Store;

class Syncer_Product extends Basic
{
    private $syncer_key;

    public function __construct(array $properties = array())
    {
        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }

        $syncer_store = new Syncer_Store();
        $this->syncer_key = $syncer_store->getKey();
    }

    public function getByIds(array $wooProductIds)
    {

    }

    public function get_all($limit = 10)
    {

    }

    public function add($api_product)
    {
        if ($this->syncer_key !== '') {
            $Woo_product = new Woo_Product();
            $woo_products = $Woo_product->get();

            $payload = array(
                'type'     => $this->syncer_type,
                'key'      => $this->syncer_key,
                'products' => $woo_products
            );

            $ch = new Curl(PRODUCT_SYNCER_API_URL . 'products');
            $response = $ch->Cpost($payload);

            return $response->success;
        }
    }

    public function list(): void
    {
        $paged = $_GET['paged'] ?? 1;

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->syncer_key . '/products/10?page=' . $paged);
        $product_data = $ch->Cget(json_encode(array()))->data;

        $properties = array('product_data' => $product_data);
        $drafts_table = new Syncer_Product_List($properties);
        ?>
        <div class="wrap">
            <h2><?php esc_html_e('All Products List', 'product-syncer'); ?></h2>
            <form id="all-drafts" method="get">
                <input type="hidden" name="page" value="product-syncer-products"/>

                <?php
                $drafts_table->prepare_items();
                $drafts_table->search_box('Search', 'search');
                $drafts_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function list_source_store()
    {
        $paged = $_GET['paged'] ?? 1;
        $syncer_store_id = 36;
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $syncer_store_id . '/sync/products?limit=10&page=' . $paged);
        $product_data = $ch->Cget(json_encode(array()))->data;

        include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'products/client/index.php';
    }

    public function push_all()
    {
        $Woo_product = new Woo_Product();
        $woo_products = $Woo_product->get();

        $payload = array(
            'type'     => $this->syncer_type,
            'key'      => $this->syncer_key,
            'products' => $woo_products
        );

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'products');
        $response = $ch->Cpost($payload);

        $syncerProducts = $response->data;

        foreach ($syncerProducts as $syncer_product) {
            $woo_product_id = $syncer_product->store_product_id;
            update_post_meta($woo_product_id, '_ufit_syncer_id', $syncer_product->id);
        }
    }

    public function get($wooProductId, $fields = 'all')
    {
    }

    public function update()
    {
    }

    public function toggle_sync($syncerProductId)
    {
        $payload = array(
            'id' => $syncerProductId
        );

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'product/toggle/sync');
        return $ch->Cpost($payload);
    }
}
