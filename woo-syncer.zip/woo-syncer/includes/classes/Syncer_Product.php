<?php

namespace Ufit\product_syncer;

defined('ABSPATH') || exit;
require_once 'Basic.php';
require_once 'Syncer_Product_List.php';
require_once 'Syncer_Store.php';

use Ufit\product_syncer\Basic as Basic;
use Ufit\product_syncer\Syncer_Product_List as Syncer_Product_List;
use Ufit\product_syncer\Syncer_Store as Syncer_Store;

class Syncer_Product extends Basic
{
    private $syncer_key;

    public function __construct(array $properties = array())
    {
        foreach ($properties as $key => $value) {
            $this->{$key} = $value;
        }

        $syncer_store = new Syncer_Store();
        $this->syncer_key = $syncer_store->getKey();
    }

    public function getByIds(array $wooProductIds)
    {
        $data = array(
            'key'               => $this->syncer_key,
            'store_product_ids' => $wooProductIds,
        );

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'get_by_ids===123');
        $response = $ch->Cpost(json_encode($data));
        var_dump($response);
        exit();
        return $ch->Cpost(json_encode($data));

    }

    public function get_all($limit = 10)
    {
        print_r(json_encode(array()));
        exit();
        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'get_by_ids===123');
        $response = $ch->Cpost(json_encode(array()));
        var_dump($response);
        exit();

    }

    public function list(): void
    {
        $paged = $_GET['paged'] ?? 1;
        

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'store/' . $this->syncer_key . '/products/10?page='.$paged);
        $product_data = $ch->Cget(json_encode(array()));

        $properties = array('product_data' => $product_data);
        $drafts_table = new Syncer_Product_List($properties);
        ?>
        <div class="wrap">
            <h2><?php esc_html_e('All Products List', 'product-syncer'); ?></h2>
            <form id="all-drafts" method="get">
                <input type="hidden" name="page" value="product-syncer-products"/>

                <?php
                $drafts_table->prepare_items();
                $drafts_table->search_box('Search', 'search');
                $drafts_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function sync_all()
    {

    }

    public function add()
    {
        $Woo_product = new Woo_Product();
        $woo_products = $Woo_product->get();


        $data = array(
            'type'     => $this->syncer_type,
            'key'      => $this->syncer_key,
            'products' => $woo_products
        );

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'products');
        $response = $ch->Cpost(json_encode($data));

        return $response->success;
    }

    public function get($wooProductId, $fields = 'all')
    {
        $data = array(
            'key'              => $this->syncer_key,
            'store_product_id' => $wooProductId,
            'fields'           => $fields,
        );

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'get===123');
        return $ch->Cpost(json_encode($data));

    }

    public function update()
    {

    }

    public function toggle_sync($wooProductId)
    {
        $data = array(
            'key'              => $this->syncer_key,
            'store_product_id' => $wooProductId
        );

        $ch = new Curl(PRODUCT_SYNCER_API_URL . 'product/toggle/sync');
        return $ch->Cpost(json_encode($data));
    }
}
