<?php
namespace Ufit\product_syncer;


class Syncer_Product
{

    private $wp_user;
    private $syncer_type;
    private $syncer_key;

    public function __construct(Array $properties=array())
    {
        $this->wp_user = wp_get_current_user();
        foreach($properties as $key => $value){
            $this->{$key} = $value;
        }
    }

    public function sync_all(){

    }

    public function add()
    {
        $Woo_product = new Woo_Product();
        $woo_products = $Woo_product->get();


        $data = array(
            'type' => $this->syncer_type,
            'key' => $this->syncer_key,
            'products' => $woo_products
        );

        $ch = NEW Curl(PRODUCT_SYNCER_API_URL.'products');
        $response = $ch->Cpost(json_encode($data));

        return $response->success;
    }

    public function get()
    {

    }

    public function update()
    {

    }

    public function hasProduct()
    {
        return false;
    }


}
