<?php

namespace Ufit\product_syncer\traits;

trait Json
{
    public function is_json($string)
    {
        if (gettype($string) !== 'string') {
            return false;
        }
        json_decode($string);
        return json_last_error() === JSON_ERROR_NONE;
    }
}
