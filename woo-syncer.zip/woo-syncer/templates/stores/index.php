<?php
include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'layouts/header.php';
?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Store Management</h2>
        </div>
        <div class="pull-right">
            <!--            <a class="btn btn-success" href="#"> Add New Store</a>-->
        </div>
    </div>
</div>


<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th># of synck</th>
        <th width="280px">Action</th>
    </tr>
    <?php
    $i = 0;
    foreach ($tores as $stor) {
        $params = array(
            'page'  => 'product-syncer-products',
//            'store' => $stor->syncer_store_id
        );

        $url = add_query_arg($params, admin_url('admin.php'));
        ?>
        <tr>
            <td><?= ++$i ?></td>
            <td><?= $stor->syncer_store_id ?></td>
            <td></td>
            <td>
                <a class="btn btn-info" href="<?= $url ?>">Products</a>
                <a class="btn btn-primary" href="{{ route('users.edit',$user->id) }}">Edit</a>
            </td>
        </tr>

        <?php
    }
    ?>
</table>


<?php
include_once PRODUCT_SYNCER_TEMPLATE_PATH . 'layouts/footer.php';
?>
