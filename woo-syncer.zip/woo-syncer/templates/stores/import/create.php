<?php
include_once PRODUCT_SYNCER_TEMPLATE_PATH.'layouts/header.php';
?>

<form method="POST" action="<?php echo admin_url( 'admin.php' ); ?>">
    <input type="hidden" name="action" value="ufit_add_source_store" />

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Store Key:</strong>
                <input type="text" name="source_store_key">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
</form>





<?php
include_once PRODUCT_SYNCER_TEMPLATE_PATH.'layouts/footer.php';
?>
