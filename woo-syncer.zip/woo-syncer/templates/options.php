<h1>Settings</h1>
<form action="options.php" method="post">
    <?php
    settings_fields('product_syncer');
    do_settings_sections('syncer_setting_page');

    $options = get_option('product_syncer');
    $store_is = isset($options['store_is'])? $options['store_is'] : '';
    ?>
    <table class="form-table" role="presentation">
        <tbody>
        <tr>
            <th scope="row">Your store is?</th>
            <td><input type="radio" name="product_syncer[store_is]" id="store_is_source"
                       value="source" <?php checked('source', $store_is, true); ?>>
                <label for="store_is_source">Source Store</label>
                <input type="radio" name="product_syncer[store_is]" id="store_is_destination"
                       value="destination" <?php checked('destination', $store_is, true); ?>>
                <label for="store_is_destination">Destination Store</label>
            </td>
        </tr>
        </tbody>
    </table>
    <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e('Save'); ?>"/>
</form>
