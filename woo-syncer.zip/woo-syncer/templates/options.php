<?php
require_once PRODUCT_SYNCER_PLUGIN_PATH.'includes/classes/Syncer_Store.php';

use Ufit\product_syncer\Syncer_Store as Syncer_Store;
?>
<h1>Settings</h1>
<form action="options.php" method="post">
    <?php
    settings_fields('product_syncer');
    do_settings_sections('syncer_setting_page');
    $Syner_Store = new Syncer_Store();
    ?>
    <table class="form-table" role="presentation">
        <tbody>
        <?php
        if (!$Syner_Store->has()) {
            ?>
            <tr>
                <th scope="row">Your store is?</th>
                <td>
                    <input type="radio" name="product_syncer[store_is]" id="store_is_source"
                           value="source" <?php checked('source', $Syner_Store->type , true); ?>>
                    <label for="store_is_source">Source Store</label>
                    <input type="radio" name="product_syncer[store_is]" id="store_is_destination"
                           value="destination" <?php checked('destination', $Syner_Store->type , true); ?>>
                    <label for="store_is_destination">Destination Store</label>
                </td>
            </tr>
            <?php
        } else {
            ?>
            <tr>
                <th scope="row">Your store Key</th>
                <td>
                    <input type="text" id="store_key" value="<?= $Syner_Store->getKey() ?>" disabled>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e('Save'); ?>"/>
</form>
